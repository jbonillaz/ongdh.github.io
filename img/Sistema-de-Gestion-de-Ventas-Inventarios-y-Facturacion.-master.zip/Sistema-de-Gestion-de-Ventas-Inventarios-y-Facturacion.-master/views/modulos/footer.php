<footer class="main-footer">
	
	<strong>Copyright &copy; 2020 <a href="" target="_blank">Sistemas de Gestion de Ventas, Inventarios y Facturacion </a>.</strong>

	Todos los derechos reservados.

</footer>