<?php

/**Metodo para destruir las sessiones  */
session_destroy();

echo '<script>

	window.location = "ingreso";

</script>';