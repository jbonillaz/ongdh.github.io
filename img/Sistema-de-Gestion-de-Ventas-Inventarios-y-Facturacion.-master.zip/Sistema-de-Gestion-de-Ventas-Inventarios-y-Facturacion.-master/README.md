# Sistema-de-Gestion-de-Ventas-Inventarios-y-Facturacion.
Sistema-de-Gestion-de-Ventas-Inventarios-y-Facturacion.

Este proyecto esta dedicado a solucionar problematicas con el tema de organizacion de inventario de productos, clientes, vendedores y ayuda a gestionar las ventas diarias.


para la utilizacion  de este programa, primeramente hay que descargarlo, 2. descomprimir el archivo, 3. instalar el gestor de bd XAMPP, 4. importar la bd que se encuentra en la  carpeta liroz/models/bd/liroz.sql
