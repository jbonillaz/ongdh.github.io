<header class="main-header">
	<!--========================================
  =         Logo del sistema        =
  =============================================-->
	<a href="inicio" class="logo">


	<!-- logo mini -->
		<span class="logo-mini">
			
			<img src="views/img/template/icono-blanco.png" class="img-responsive" style="padding:10px">

		</span>

		<!-- logo normal -->

		<span class="logo-lg">
			
			<img src="views/img/template/logo-blanco-lineal.png" class="img-responsive" style="padding:100px 5px">

		</span>
	</a>	
	<!--========================================
  =         Navigation Bar       =
  =============================================-->
</header>